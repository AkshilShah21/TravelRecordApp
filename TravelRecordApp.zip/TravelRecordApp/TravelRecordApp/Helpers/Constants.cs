﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TravelRecordApp.Helpers
{
    public class Constants
    {
        public const string VENUE_SEARCH = "https://api.foursquare.com/v3/places/nearby?ll={0}%2C{1}";
        public const string key = "fsq3OjqhBtwNUeMbwJyy948zmQ5NnuTz0Aw8VRSD8EHpmws=";
    }
}


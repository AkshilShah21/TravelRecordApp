﻿using System;
using System.Collections.Generic;
using System.Text;
using TravelRecordApp.Model;
using System.Net.Http;
using System.Threading.Tasks;

using Newtonsoft.Json;
using System.Net.Http.Headers;
using TravelRecordApp.Helpers;

namespace TravelRecordApp.Logic
{
    class VenueLogic
    {
        //public double latitude = 21.1702401;
        //       pu double longitude = 72.8310607;
        public async static Task<List<Result>> GetVenues(double latitude, double longitude)
        {
            List<Result> venues = new List<Result>();
           
            var url = Root1.GenreateURL(latitude, longitude);

            /*
           var client = new RestClient(url);
           RestRequest request = new RestRequest("", Method.Get);
           request.AddHeader("Accept", "application/json");
           request.AddHeader("Authorization", Constants.key);
          var response = await client.ExGetAsync(request);
          var json = JsonConvert.DeserializeObject<VenueRoot>(result);
            */


            /*HttpClient client = new HttpClient();
            var request = new HttpRequestMessage()
            {
                    RequestUri = new Uri(url),
                    Method = HttpMethod.Get,
            };
            request.Headers.Add("Accept", "application/json");
            request.Headers.Add("Authorization", Constants.key);
              var response = await client.SendAsync(request);    
            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                var json = await response.Content.ReadAsStringAsync();
                var venueRoot = JsonConvert.DeserializeObject<VenueRoot>(json);
                venues = venueRoot.response.venues as List<Venue>;
            }*/
            HttpClient client = new HttpClient();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            client.DefaultRequestHeaders.TryAddWithoutValidation("Authorization", "fsq3DCjjiW66poKmwL7aoRcMr3CcZiRv5FwWPh3wCR5R69o=");
             
            var responce =await client.GetAsync(url);
            Console.WriteLine(responce.StatusCode);
            if (responce.StatusCode == System.Net.HttpStatusCode.OK)
            {
                var json = await responce.Content.ReadAsStringAsync();
                var venueRoot = JsonConvert.DeserializeObject<Root>(json);
                venues = venueRoot.results;
            }
            return venues;
        }
    }
}

﻿using System;

namespace TravelRecordApp.Model
{
    internal class PrimarykeyAttribute : Attribute
    {
    }
}
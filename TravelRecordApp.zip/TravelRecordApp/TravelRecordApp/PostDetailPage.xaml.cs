﻿using SQLite;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TravelRecordApp.Helpers;
using TravelRecordApp.Model;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace TravelRecordApp
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class PostDetailPage : ContentPage
    {
        private Post _selectPost;
        public PostDetailPage(Post selectedPost)
        {
            InitializeComponent();
            _selectPost = selectedPost;
            experienceEntry.Text = _selectPost.Experience;
        }
        private async void updateButton_Clicked(object sender, EventArgs e)
        {
            _selectPost.Experience = experienceEntry.Text;
            using (SQLiteConnection conn = new SQLiteConnection(App.DatabaseLocation))
            {
                conn.CreateTable<Post>();
                int rows = conn.Update(_selectPost);
                if (rows > 0)
                   await DisplayAlert("success", "Experience succesfully udpdated", "Ok");
                else
                   await DisplayAlert("failure", "Experience failed to update ", "Ok");
                /*bool result = await Firestore.Update(_selectPost);
                if (result)
                    await Navigation.PopAsync();*/
            }
        }
        private async void deleteButton_Clicked(object sender, EventArgs e)
        {
            using (SQLiteConnection conn = new SQLiteConnection(App.DatabaseLocation))
            {
                conn.CreateTable<Post>();
                int rows = conn.Delete(_selectPost);
                if (rows > 0)
                  await  DisplayAlert("success", "Experience succesfully delete", "Ok");
                else
                   await DisplayAlert("failure", "Experience failure to be deleted", "Ok");
                /* bool result = await Firestore.Delete(_selectPost);
                 if (result)
                     await Navigation.PopAsync();*/
            }
        }
    }
}